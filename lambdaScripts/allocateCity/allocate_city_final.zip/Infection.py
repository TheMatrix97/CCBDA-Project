from enum import Enum
class Infection(Enum):
    INCUBATION = 0
    INFECTION_ASIMP = 1
    INFECTION_SIMP = 2
    IMMUNE = 3
    DEATH = 4
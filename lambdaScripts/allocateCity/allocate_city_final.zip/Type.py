from enum import Enum


class Type(Enum):
    WORKPLACE = 0
    SCHOOL = 1
    HOME = 2
    OTHER = 3

